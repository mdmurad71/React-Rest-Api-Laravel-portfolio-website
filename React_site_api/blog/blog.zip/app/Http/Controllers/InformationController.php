<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\InformationModel;

class InformationController extends Controller
{
    function onAllSelect(){
        $result=InformationModel::all();
        return $result;
    }
}
